import pathlib,json,hashlib,decimal,sys
R=pathlib.Path(__file__).resolve().parent.parent;repo=R/'work/doc-supplement';sys.path.insert(0,str(repo/'scripts/audit'))
from osm_acq2c_frontier import normalize_regional
from osm_acq2c_selected_epoch_replay import verify_manifest
D=R/'outputs/ROADMAP-20261024/round2-gap-readonly-current';old=repo/'docs/evidence/osm-acq2c-gap-state-20261023';verify_manifest(old);prior=json.loads((old/'report.json').read_bytes());rows=list(prior['rows']);codes={'n249478464','n281664933','n313853846','n476084381','w28535366'};epoch='2026-10-20T20:23:47Z'
source=R/'work/osm-acq2c-bulk/recursive-round2-epoch-20261023';manifest=json.loads((source/'manifest-sha256.json').read_bytes());bound={x['name']:x for x in manifest['files']}
def check(p,record):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8388608),b''):h.update(b)
 if p.stat().st_size!=record['bytes'] or h.hexdigest()!=record['sha256']:raise ValueError('Frozen input changed')
for n in ('selected-target.json','selected-history.jsonl'):check(source/n,bound[n])
target=json.loads((source/'selected-target.json').read_bytes());histories={c:[] for c in codes}
for line in (source/'selected-history.jsonl').open('rb'):
 row=json.loads(line)
 if row['code'] in codes:histories[row['code']].append(row)
current={};receipts=json.loads((D/'receipts.json').read_bytes())
for receipt in receipts:
 p=D/receipt['private_original'];raw=p.read_bytes()
 if len(raw)!=receipt['bytes'] or hashlib.sha256(raw).hexdigest()!=receipt['sha256']:raise ValueError('API original changed')
 if receipt['status']==200:
  data=json.loads(raw,parse_float=decimal.Decimal)
  for obj in data['elements']:
   code={'node':'n','way':'w','relation':'r'}[obj['type']]+str(obj['id'])
   if code not in codes or code in current:raise ValueError('Unexpected/duplicate API identity')
   current[code]=normalize_regional(obj,epoch)
if set(current)!=codes:raise ValueError('Incomplete current state proof')
new=[]
for code in sorted(codes):
 observed=sorted({r['version'] for r in histories[code]});missing=sorted(set(range(1,max(observed)+1))-set(observed))
 if not missing:raise ValueError('Expected observed version gap disappeared')
 same=current[code]==target[code]
 access=next((r for r in receipts if r['label']=='missing-node249478464-v2'),None) if code=='n249478464' else None
 new.append(dict(code=code,observed_versions=observed,missing_versions=missing,missing_observed_versions=len(missing),target_version=target[code]['version'],target_timestamp=target[code]['timestamp'],current_version=current[code]['version'],current_timestamp=current[code]['timestamp'],current_observation='CURRENT_EQUALS_REPLAY_TARGET' if same else 'CURRENT_DIFFERS_FROM_REPLAY_TARGET',historical_continuity='BLOCKED_VERSION_GAPS',missing_version_access=dict(status=access['status'],sha256=access['sha256'],bytes=access['bytes']) if access else dict(status='NOT_REQUESTED_AFTER_FIRST_403'),history_gaps_resolved=0,source_qualified=False))
if set(r['code'] for r in rows)&codes or len(rows)!=102 or sum(r['missing_observed_versions'] for r in rows)!=250:raise ValueError('Original cohort changed')
rows+=new
if len(rows)!=107 or len({r['code'] for r in rows})!=107:raise ValueError('Cohort duplicate/loss')
report=dict(epoch=epoch,objects=107,original_cohort_objects=102,original_cohort_missing_versions=250,additional_objects=5,additional_missing_versions=sum(r['missing_observed_versions'] for r in new),missing_observed_versions=sum(r['missing_observed_versions'] for r in rows),history_gaps_resolved=0,source_qualified=False,provenance_human_or_signed_validation_pending=True,rows=rows,new_current_receipts=receipts,previous_cohort_manifest_sha256=hashlib.sha256((old/'manifest-sha256.json').read_bytes()).hexdigest(),new_target_history_binding=bound,scope='Public current-state agreement does not recover unavailable versions or prove historical continuity; 403 cause is not inferred and restrictions are not bypassed.')
out=R/'outputs/ROADMAP-20261024/gap-cohort107';out.mkdir(exist_ok=False);raw=(json.dumps(report,sort_keys=True,indent=2)+'\n').encode();(out/'report.json').write_bytes(raw);(out/'manifest-sha256.json').write_bytes((json.dumps(dict(files=[dict(name='report.json',bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())],source_qualified=False),indent=2)+'\n').encode());print(json.dumps({k:v for k,v in report.items() if k not in ('rows','new_current_receipts','new_target_history_binding')}))
