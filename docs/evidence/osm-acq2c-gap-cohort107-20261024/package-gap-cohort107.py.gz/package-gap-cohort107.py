import pathlib,json,hashlib,gzip,decimal,sys
R=pathlib.Path(__file__).resolve().parent.parent;repo=R/'work/doc-supplement';sys.path.insert(0,str(repo/'scripts/audit'));from osm_acq2c_gap_state import inspect_gap
from osm_acq2c_gap_cohort import extend_cohort
from osm_acq2c_frontier import normalize_regional
from osm_acq2c_selected_epoch_replay import verify_manifest
old=repo/'docs/evidence/osm-acq2c-gap-state-20261023';verify_manifest(old);prior=json.loads((old/'report.json').read_bytes());private=R/'outputs/ROADMAP-20261024/gap-cohort107';verify_manifest(private);aggregate=json.loads((private/'report.json').read_bytes());codes={'n249478464','n281664933','n313853846','n476084381','w28535366'};epoch=aggregate['epoch'];api=R/'outputs/ROADMAP-20261024/round2-gap-readonly-current';receipts=json.loads((api/'receipts.json').read_bytes());current={}
for receipt in receipts:
 raw=(api/receipt['private_original']).read_bytes()
 if len(raw)!=receipt['bytes'] or hashlib.sha256(raw).hexdigest()!=receipt['sha256']:raise ValueError('Current API original changed')
 if receipt['status']==200:
  for obj in json.loads(raw,parse_float=decimal.Decimal)['elements']:
   row=normalize_regional(obj,epoch);current[row['code']]=row
source=R/'work/osm-acq2c-bulk/recursive-round2-epoch-20261023';history={c:[] for c in codes};target=json.loads((source/'selected-target.json').read_bytes())
for line in (source/'selected-history.jsonl').open('rb'):
 row=json.loads(line)
 if row['code'] in codes:history[row['code']].append(row)
def sparse(row):return dict(code=row['code'],version=row['version'],timestamp=row['timestamp'],visible=row['visible'],payload_sha256=hashlib.sha256((json.dumps(row,sort_keys=True,separators=(',',':'),ensure_ascii=False)+'\n').encode()).hexdigest())
capsule=dict(epoch=epoch,histories={c:[sparse(r) for r in history[c]] for c in sorted(codes)},targets={c:sparse(target[c]) for c in sorted(codes)},current={c:sparse(current[c]) for c in sorted(codes)},source_qualified=False,private_originals_uploaded=False)
rows=[]
for code in sorted(codes):
 row=inspect_gap(code,capsule['histories'][code],capsule['targets'][code],capsule['current'][code],epoch)
 observed=set(row['observed_versions']);row['missing_versions']=[v for v in range(1,max(observed)+1) if v not in observed]
 oldrow=next(r for r in aggregate['rows'] if r['code']==code)
 for key in ('missing_observed_versions','observed_versions','current_observation','target_version','current_version'):
  if row[key]!=oldrow[key]:raise ValueError('Independent gap arithmetic disagrees')
 row['missing_version_access']=oldrow['missing_version_access'];rows.append(row)
delta=dict(rows=rows,epoch=epoch,source_qualified=False,history_gaps_resolved=0,previous_cohort_manifest_sha256=hashlib.sha256((old/'manifest-sha256.json').read_bytes()).hexdigest(),private_originals_uploaded=False,current_receipts=receipts,source_history_binding=aggregate['new_target_history_binding'])
result=extend_cohort(prior,delta)
if (result['objects'],result['missing_observed_versions'])!=(107,262):raise ValueError('Cohort totals differ')
out=repo/'docs/evidence/osm-acq2c-gap-cohort107-20261024';out.mkdir(exist_ok=False)
def emit(n,v):(out/n).write_bytes((json.dumps(v,sort_keys=True,indent=2)+'\n').encode())
emit('delta.json',delta);(out/'sparse-capsule.json.gz').write_bytes(gzip.compress((json.dumps(capsule,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0));emit('summary.json',dict(objects=107,old_objects=102,new_objects=5,old_missing_versions=250,new_missing_versions=12,missing_observed_versions=262,history_gaps_resolved=0,source_qualified=False,provenance_human_or_signed_validation_pending=True,prior_manifest_sha256=delta['previous_cohort_manifest_sha256'],all_new_current_states_equal_target=True,missing_version_http403_observed=1,remaining_missing_version_probes='NOT_REQUESTED_AFTER_FIRST_403',private_originals_uploaded=False))
(out/'reconcile-gap-cohort107.py.gz').write_bytes(gzip.compress((R/'work/reconcile-gap-cohort107.py').read_bytes(),mtime=0));(out/'package-gap-cohort107.py.gz').write_bytes(gzip.compress(pathlib.Path(__file__).read_bytes(),mtime=0));files=[dict(name=p.name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(out.iterdir())];emit('manifest-sha256.json',dict(files=files,source_qualified=False));print(json.dumps(dict(status='PASS',objects=107,missing_observed_versions=262,new_objects=5,new_missing_versions=12,history_gaps_resolved=0,manifest_sha256=hashlib.sha256((out/'manifest-sha256.json').read_bytes()).hexdigest())))
