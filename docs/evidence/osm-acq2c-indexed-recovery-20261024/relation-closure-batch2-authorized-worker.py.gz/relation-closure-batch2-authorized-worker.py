"""One native reread of the previously verified immutable base, no download/hash rerun."""
import pathlib,sys,os,json,hashlib,datetime,traceback
ROOT=pathlib.Path(__file__).resolve().parent.parent
sys.path[:0]=[str(ROOT/'work/gis-runtime'),str(ROOT/'work/doc-supplement/scripts/audit')]
from osm_acq2c_native_extract import request_ids,BASE_EPOCH,canonical
import pbf_indexed_relation_ranges_v2 as reader
read_selection=reader.read_selection
BULK=ROOT/'work/osm-acq2c-bulk'
OUT=BULK/'relation-closure-batch2-base-authorized-20261024'
PLAN=BULK/'relation-closure-batch2-ids.txt'
reader.OUTPUT_DIRECTORY=OUT
def emit(p,v):p.write_bytes(canonical(v))
def run():
 OUT.mkdir(exist_ok=False)
 with (OUT/'exclusive-lock.json').open('x') as lock:json.dump(dict(pid=os.getpid(),started_at=datetime.datetime.now(datetime.timezone.utc).isoformat()),lock)
 state=dict(pid=os.getpid(),phase='STARTED',source_qualified=False,source_promoted=False,download_started=False)
 def status(**extra):
  state.update(extra,updated_at=datetime.datetime.now(datetime.timezone.utc).isoformat());temp=OUT/'worker.tmp';emit(temp,state);os.replace(temp,OUT/'worker.json')
 try:
  code_paths=[pathlib.Path(__file__),ROOT/'work/pbf_indexed_relations.py',ROOT/'work/pbf_indexed_relation_ranges_v2.py',ROOT/'work/pbf_index_payload.py',ROOT/'work/doc-supplement/scripts/audit/osm_acq2c_native_extract.py',ROOT/'work/doc-supplement/scripts/audit/osm_acq2c_pbf_blocks.py'];code_sha256={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in code_paths}
  source=BULK/'history-261019.osm.pbf';before=source.stat()
  old_stat=json.loads((BULK/'recursive-frontier-base-20261023/worker.json').read_bytes())['source_stat']
  if (before.st_size,before.st_mtime_ns)!=(old_stat['bytes'],old_stat['mtime_ns']):raise ValueError('Immutable base stat changed since prior extraction')
  if hashlib.sha256(PLAN.read_bytes()).hexdigest()!='0e99f3a7990e6e2ddbb6a32c4796620c248b47a5713e3f59caa157933152041e':raise ValueError('Round2 plan changed')
  proof=ROOT/'outputs/ROADMAP-20261023/checkpoint-20261023T101735Z-99edf59/base-independent-integrity.json'
  raw=proof.read_bytes()
  if hashlib.sha256(raw).hexdigest()!='4c8a0e8a974402dcebda42627b9c3aa5d956aba2219657e20cfa15b47f955943':raise ValueError('Prior independent integrity proof changed')
  integrity=json.loads(raw)
  if before.st_size!=integrity['bytes'] or integrity['sha256']!='149ce6e8d1d4aad41e94fddb8f9721f80697d42d51e5f612879c98d1c236e5a9':raise ValueError('Base identity changed')
  ids=request_ids(PLAN.read_text().splitlines());status(phase='NATIVE_FILTERING',requested=len(ids),source_stat=dict(bytes=before.st_size,mtime_ns=before.st_mtime_ns),prior_integrity_reused=True,original_rehashed=False,plan_sha256=hashlib.sha256(PLAN.read_bytes()).hexdigest())
  last={};versions={};gaps={};count=0;digest=hashlib.sha256()
  with (OUT/'selected-base-history.jsonl').open('xb') as target:
   for row in read_selection(source,ids,BASE_EPOCH):
    code=row['code'];v=row['version'];old=last.get(code)
    if old and (v<=old['version'] or row['timestamp']<old['timestamp']):raise ValueError('Nonmonotonic/duplicate history: '+code)
    previous=old['version'] if old else 0
    if v!=previous+1:gaps.setdefault(code,[]).append([previous+1,v-1])
    last[code]=row;versions[code]=versions.get(code,0)+1
    raw=canonical(row);target.write(raw);digest.update(raw);count+=1
    if count%100000==0:status(observed=len(last),versions=count)
  if code_sha256!={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in code_paths}:raise ValueError('Indexed reader code changed during extraction')
  after=source.stat()
  if (before.st_size,before.st_mtime_ns)!=(after.st_size,after.st_mtime_ns):raise ValueError('Source changed during extraction')
  emit(OUT/'selected-base-latest.json',last)
  report=dict(code_sha256=code_sha256,publisher_sort_order_used_as_unverified_assumption=True,global_sorting_verified=False,requested=len(ids),observed=len(last),versions=count,missing_ids=sorted(ids-last.keys()),history_gap_ranges=gaps,base_epoch=BASE_EPOCH,target_epoch_not_reached=True,source_qualified=False,independent_human_or_signed_validation_pending=True,prior_integrity_reused=True,original_rehashed=False,source_stat_unchanged=True,history_sha256=digest.hexdigest(),contributor_metadata_exported=False)
  emit(OUT/'report.json',report)
  files=[]
  for p in sorted(OUT.iterdir()):
   if p.name in ('worker.json','exclusive-lock.json'):continue
   h=hashlib.sha256()
   with p.open('rb') as stream:
    for block in iter(lambda:stream.read(8388608),b''):h.update(block)
   files.append(dict(name=p.name,bytes=p.stat().st_size,sha256=h.hexdigest()))
  emit(OUT/'manifest-sha256.json',dict(files=files,source_qualified=False))
  status(phase='BASE_EXTRACT_FINISHED_UNQUALIFIED',observed=len(last),versions=count,missing=len(report['missing_ids']),gapped=len(gaps))
 except Exception as e:
  status(phase='STOPPED_WITHOUT_QUALIFICATION',error=str(e));(OUT/'failure.txt').write_text(traceback.format_exc());raise
if __name__=='__main__':run()
