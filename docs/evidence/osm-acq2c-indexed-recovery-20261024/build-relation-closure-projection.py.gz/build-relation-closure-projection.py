"""Project only relation-member edges; no polygon or jurisdiction acceptance."""
import pathlib,sys,json,gzip,hashlib,collections,datetime
ROOT=pathlib.Path(__file__).resolve().parent.parent
sys.path[:0]=[str(ROOT/'work/gis-runtime'),str(ROOT/'work/doc-supplement/scripts/audit')]
from osm_acq2c_frontier import normalize_regional
from osm_acq2c_selected_epoch_replay import verify_manifest
from preserved_history_overlay import load_preserved
EPOCH='2026-10-20T20:23:47Z';known={};inputs=[]
def sha(raw):return hashlib.sha256(raw).hexdigest()
def merge(row):
    code=row['code']
    if code in known and known[code]!=row:raise ValueError('Conflicting relation source: '+code)
    known[code]=row
def discard_nonrelation(obj):
    if 'version' in obj and 'timestamp' in obj and (obj.get('type') in ('node','way') and 'id' in obj or isinstance(obj.get('code'),str) and obj['code'][:1] in ('n','w')):return None
    return obj
packet=ROOT/'work/doc-supplement/docs/evidence/osm-acq2c-recursive-frontier-20261023';verify_manifest(packet)
bound=json.loads((packet/'summary.json').read_bytes())['inputs'];base=pathlib.Path((ROOT/'work/current-osm-resume-20261022.txt').read_text().strip())/'extract-replay-v2'
for descriptor in json.loads((base/'report.json').read_bytes())['reports']:
    previous=next(x for x in bound if pathlib.Path(x['path']).name==descriptor['raw_file'])
    packed=(base/descriptor['raw_file']).read_bytes()
    if sha(packed)!=previous['sha256'] or sha(packed)!=descriptor['raw_gzip_sha256'] or descriptor['header']['osmosis_replication_timestamp']!=EPOCH:raise ValueError('Regional compressed source changed')
    raw=gzip.decompress(packed)
    if sha(raw)!=previous['body_sha256'] or sha(raw)!=descriptor['raw_body_sha256']:raise ValueError('Regional body changed')
    rows=json.loads(raw,object_hook=discard_nonrelation)['elements'];seen=set()
    for row in rows:
        if row is None:continue
        if row.get('type')!='relation':raise ValueError('Unexpected regional object type')
        normalized=normalize_regional(row,EPOCH)
        if normalized['code'] in seen:raise ValueError('Duplicate regional relation')
        seen.add(normalized['code']);merge(normalized)
    inputs.append(dict(kind='regional_relation_projection',country=descriptor['country'],gzip_sha256=sha(packed),body_sha256=sha(raw),relations=len(seen)))
    del packed,raw,rows
for folder in ('selected-epoch-published-20261023','recursive-frontier-epoch-20261023','recursive-round2-epoch-20261023','relation-ranges-epoch-20261023'):
    directory=ROOT/'work/osm-acq2c-bulk'/folder;verify_manifest(directory)
    raw=(directory/'selected-target.json').read_bytes();rows=json.loads(raw,object_hook=discard_nonrelation);count=0
    for code,row in rows.items():
        if row is None:continue
        if not code.startswith('r') or row['code']!=code:raise ValueError('Unexpected historical projection')
        merge(row);count+=1
    inputs.append(dict(kind='historical_relation_projection',folder=folder,selected_sha256=sha(raw),manifest_sha256=sha((directory/'manifest-sha256.json').read_bytes()),relations=count))
    del raw,rows
legacy,legacy_receipt=load_preserved(ROOT/'work/doc-supplement/docs/evidence/osm-acq2b-node-history-20261022',ROOT/'work/doc-supplement/docs/evidence/osm-acq2b-way-history-20261022',EPOCH)
for row in legacy:
    if row['type']=='relation':merge(normalize_regional(row,EPOCH))
selector=ROOT/'outputs/ROADMAP-20261023/full-frozen-selector-preserved-20261023/readiness.json';raw=selector.read_bytes()
if sha(raw)!='acad86117390afa1aae0fdfba903a8808aa432b1bb19d9241b258bc17bd8a39b':raise ValueError('Root inventory changed')
roots=sorted({'r'+str(x['id']) for x in json.loads(raw)['rows']});visited=set();missing={};ways=set();nodes=set();queue=collections.deque(roots)
while queue:
    code=queue.popleft()
    if code in visited:continue
    visited.add(code);row=known.get(code)
    if row is None:continue
    if row['visible'] is not True:raise ValueError('Invisible relation referenced')
    for typ,ref,role in row['members']:
        if typ=='r':
            child='r'+str(ref)
            if child not in known:missing.setdefault(child,set()).add(code)
            else:queue.append(child)
        elif typ=='w':ways.add('w'+str(ref))
        elif typ=='n':nodes.add('n'+str(ref))
        else:raise ValueError('Unknown relation member type')
previous=ROOT/'outputs/ROADMAP-20261024/relation-ranges-all-candidate-recursive-frontier-20261024/report.json';prior_raw=previous.read_bytes();prior=json.loads(prior_raw)
expected={r['code'] for r in prior['missing'] if r['code'].startswith('r')}
if set(missing)!=expected:raise ValueError('Relation-only frontier differs from full-graph traversal')
out=ROOT/'work/osm-acq2c-bulk/relation-closure-projection-20261024';out.mkdir(exist_ok=False)
def emit(name,value):
    raw=(json.dumps(value,sort_keys=True,separators=(',',':'))+'\n').encode();(out/name).write_bytes(raw)
emit('known-relations.json',known);emit('report.json',dict(epoch=EPOCH,known_relations=len(known),visited_relations=len(visited),roots=roots,missing_relations=[dict(code=c,parents=sorted(missing[c])) for c in sorted(missing)],relation_graph_closed=not missing,direct_way_count=len(ways),direct_node_count=len(nodes),inputs=inputs,full_graph_crosscheck_sha256=sha(prior_raw),source_qualified=False,global_sorting_verified=False,publisher_sort_order_used_as_unverified_assumption=True,topology_certified=False,recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat()))
files=[dict(name=p.name,bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in sorted(out.iterdir())];emit('manifest-sha256.json',dict(files=files,source_qualified=False))
print(json.dumps(dict(known_relations=len(known),visited_relations=len(visited),missing_relations=len(missing),direct_way_count=len(ways),direct_node_count=len(nodes),relation_graph_closed=not missing,source_qualified=False)))
