import unittest,pathlib,sys
root=pathlib.Path(__file__).resolve().parent.parent;sys.path[:0]=[str(root/'work/gis-runtime'),str(root/'work/doc-supplement/scripts/audit')]
from pbf_indexed_relation_ranges import overlap,relation_bounds
def varint(n):
    out=[]
    while n>=128:out.append((n&127)|128);n>>=7
    return bytes(out+[n])
def data(n,v):return varint((n<<3)|2)+varint(len(v))+v
def block(ids):return data(1,data(1,b'')+data(2,b''.join(data(4,b'\x08'+varint(n)) for n in ids)))
class Tests(unittest.TestCase):
    def test_all_overlapping_version_blocks(self):
        ranges=[(1,4),(4,4),(4,7),(8,9)];self.assertEqual(list(overlap(0,4,4,ranges.__getitem__)),[0,1,2])
    def test_absent_between_blocks(self):self.assertEqual(list(overlap(0,2,5,[(1,3),(8,9)].__getitem__)),[])
    def test_first_last_boundaries(self):
        r=[(1,4),(5,8)];self.assertEqual(list(overlap(0,2,1,r.__getitem__)),[0]);self.assertEqual(list(overlap(0,2,8,r.__getitem__)),[1])
    def test_duplicate_requested_id_maps_same_blocks(self):
        r=[(1,4),(4,9)];self.assertEqual(set(overlap(0,2,4,r.__getitem__)),{0,1})
    def test_outside_min_max(self):
        r=[(2,4)];self.assertEqual(list(overlap(0,1,1,r.__getitem__)),[]);self.assertEqual(list(overlap(0,1,5,r.__getitem__)),[])
    def test_actual_protobuf_bounds(self):self.assertEqual(relation_bounds(block([1,1,4,9]))[:2],(1,9))
    def test_reverse_bound_rejected(self):self.assertRaises(ValueError,relation_bounds,block([9,1]))
    def test_zero_identity_rejected(self):self.assertRaises(ValueError,relation_bounds,block([0]))
if __name__=='__main__':unittest.main()
