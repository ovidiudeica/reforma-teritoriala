import pathlib,json,hashlib,collections
ROOT=pathlib.Path(__file__).resolve().parent.parent;B=ROOT/'work/osm-acq2c-bulk'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def verify(d):
 for r in json.loads((d/'manifest-sha256.json').read_bytes())['files']:
  if pathlib.Path(r['name']).name!=r['name']:raise ValueError('Unsafe name')
  p=d/r['name']
  if p.stat().st_size!=r['bytes'] or sha(p)!=r['sha256']:raise ValueError('Changed input')
prior=B/'relation-closure-projection-20261024';batch=B/'relation-closure-batch1-epoch-20261024';verify(prior);verify(batch)
known=json.loads((prior/'known-relations.json').read_bytes());before=json.loads((prior/'report.json').read_bytes());added=[]
for code,row in json.loads((batch/'selected-target.json').read_bytes()).items():
 if code in known and known[code]!=row:raise ValueError('Cross-domain or control conflict '+code)
 if code not in known:added.append(code)
 known[code]=row
if len(added)!=465:raise ValueError('Wrong new identity count')
queue=collections.deque(before['roots']);visited=set();missing={};ways=set();nodes=set()
while queue:
 code=queue.popleft()
 if code in visited:continue
 visited.add(code);row=known[code]
 if not row['visible']:raise ValueError('Invisible referenced relation')
 for typ,ref,role in row['members']:
  child=typ+str(ref)
  if typ=='r':
   if child in known:queue.append(child)
   else:missing.setdefault(child,set()).add(code)
  elif typ=='w':ways.add(child)
  elif typ=='n':nodes.add(child)
  else:raise ValueError('Invalid member')
out=B/'relation-closure-projection-batch1-20261024';out.mkdir(exist_ok=False)
report=dict(epoch=before['epoch'],known_relations=len(known),visited_relations=len(visited),roots=before['roots'],new_relations=sorted(added),missing_relations=[dict(code=c,parents=sorted(missing[c])) for c in sorted(missing)],direct_way_count=len(ways),direct_node_count=len(nodes),relation_graph_closed=not missing,global_sorting_verified=False,publisher_sort_order_used_as_unverified_assumption=True,source_qualified=False,dependency_closure_certified=False,input_manifests={d.name:sha(d/'manifest-sha256.json') for d in (prior,batch)})
def emit(n,v):(out/n).write_bytes((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
emit('known-relations.json',known);emit('report.json',report);emit('manifest-sha256.json',dict(files=[dict(name=p.name,bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(out.iterdir())],source_qualified=False));print(json.dumps({k:v for k,v in report.items() if k not in ('roots','new_relations','missing_relations')}|{'missing_relations':len(missing)}))
