"""Private bounded PBF payload inspection for an explicitly conditional index."""
import zlib
from osm_acq2c_pbf_blocks import fields,MAX_BLOB

def unpack_blob(blob):
    rows=fields(blob);values=[(n,v) for n,w,v in rows if n in (1,3,4,5,6,7) and w==2]
    if len(values)!=1 or values[0][0] not in (1,3):raise ValueError('Unsupported or ambiguous blob compression')
    sizes=[v for n,w,v in rows if n==2 and w==0]
    if len(sizes)>1 or any(n==2 and w!=0 for n,w,v in rows):raise ValueError('Invalid raw size field')
    kind,data=values[0]
    if kind==3:
        if len(sizes)!=1 or not 0<sizes[0]<=MAX_BLOB:raise ValueError('Invalid decompressed size')
        dec=zlib.decompressobj();data=dec.decompress(data,MAX_BLOB+1)
        if len(data)>MAX_BLOB or not dec.eof or dec.unused_data or dec.unconsumed_tail:raise ValueError('Incomplete or excessive compressed data')
    if len(data)>MAX_BLOB or sizes and sizes[0]!=len(data):raise ValueError('Blob size mismatch')
    return data

def entity_types(blob):
    rows=fields(unpack_blob(blob));tables=[v for n,w,v in rows if n==1 and w==2]
    if len(tables)!=1:raise ValueError('Missing or duplicate string table')
    kinds=set();groups=0
    for number,wire,value in rows:
        if number!=2:continue
        if wire!=2:raise ValueError('Invalid primitive group')
        groups+=1;group=set()
        for n,w,v in fields(value):
            if n not in (1,2,3,4,5) or w!=2:raise ValueError('Unsupported primitive group field')
            if n==5:raise ValueError('Changeset block unsupported')
            group.add({1:'n',2:'n',3:'w',4:'r'}[n])
        if len(group)!=1:raise ValueError('Empty or mixed primitive group')
        kinds.update(group)
    if not groups or not kinds:raise ValueError('Empty primitive block')
    return kinds

def declared_sorted_history(header_blob):
    rows=fields(unpack_blob(header_blob))
    required=[v for n,w,v in rows if n==4 and w==2];optional=[v for n,w,v in rows if n==5 and w==2]
    if b'HistoricalInformation' not in required or b'Sort.Type_then_ID' not in optional:raise ValueError('Required publisher declarations absent')
    return {'historical_information_declared':True,'sorted_type_then_id_declared':True,'global_sorting_verified':False,'source_qualified':False}
