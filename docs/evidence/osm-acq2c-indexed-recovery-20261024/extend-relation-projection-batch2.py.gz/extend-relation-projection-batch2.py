import pathlib,json,hashlib,sys
ROOT=pathlib.Path(__file__).resolve().parent.parent;B=ROOT/'work/osm-acq2c-bulk';sys.path.insert(0,str(ROOT/'work/doc-supplement/scripts/audit'))
from osm_acq2c_relation_closure import merge_relations,project_relations

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def verify(d):
 for r in json.loads((d/'manifest-sha256.json').read_bytes())['files']:
  if pathlib.Path(r['name']).name!=r['name']:raise ValueError('Unsafe name')
  p=d/r['name']
  if p.stat().st_size!=r['bytes'] or sha(p)!=r['sha256']:raise ValueError('Changed input')
prior=B/'relation-closure-projection-batch1-20261024';batch=B/'relation-closure-batch2-epoch-20261024';verify(prior);verify(batch)
a=json.loads((prior/'known-relations.json').read_bytes());b=json.loads((batch/'selected-target.json').read_bytes());before=json.loads((prior/'report.json').read_bytes());known=merge_relations(a,b);report=project_relations(known,before['roots']);report.update(epoch=before['epoch'],new_relation_count=len(set(b)-set(a)),input_manifests={d.name:sha(d/'manifest-sha256.json') for d in (prior,batch)},global_sorting_verified=False,publisher_sort_order_used_as_unverified_assumption=True)
out=B/'relation-closure-projection-batch2-20261024';out.mkdir(exist_ok=False)
def emit(n,v):(out/n).write_bytes((json.dumps(v,sort_keys=True,separators=(',',':'))+'\n').encode())
emit('known-relations.json',known);emit('report.json',report);emit('manifest-sha256.json',dict(files=[dict(name=p.name,bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(out.iterdir())],source_qualified=False));print(json.dumps({k:v for k,v in report.items() if k not in ('roots','direct_way_ids','direct_node_ids','missing_relations')}|dict(missing_relations=len(report['missing_relations']),direct_way_count=len(report['direct_way_ids']),direct_node_count=len(report['direct_node_ids']))))
