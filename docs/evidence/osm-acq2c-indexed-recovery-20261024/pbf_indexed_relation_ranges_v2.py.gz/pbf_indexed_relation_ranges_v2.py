"""Conditional per-ID relation-block lookup, not a global sorting certificate."""
import pathlib,sys,json,hashlib,struct,time
ROOT=pathlib.Path(__file__).resolve().parent.parent
sys.path[:0]=[str(ROOT/'work/gis-runtime'),str(ROOT/'work/doc-supplement/scripts/audit')]
from osm_acq2c_pbf_blocks import fields,blob_header
from pbf_index_payload import unpack_blob,entity_types,declared_sorted_history
from pbf_indexed_relations import validate_index,first_relation
from osm_acq2c_native_extract import object_record,canonical
OUTPUT_DIRECTORY=None

def relation_bounds(blob):
    kinds=entity_types(blob);ranges=[]
    for n,w,group in fields(unpack_blob(blob)):
        if n!=2:continue
        relations=[v for k,wire,v in fields(group) if k==4 and wire==2]
        if not relations:continue
        ends=[]
        for record in (relations[0],relations[-1]):
            ids=[v for k,wire,v in fields(record) if k==1 and wire==0]
            if len(ids)!=1 or not 0<ids[0]<2**63:raise ValueError('Invalid relation identifier in block')
            ends.append(ids[0])
        if ends[0]>ends[1] or ranges and ranges[-1][1]>ends[0]:raise ValueError('Declared ID order contradicted')
        ranges.append(tuple(ends))
    if not ranges:raise ValueError('No relation IDs in relation block')
    return ranges[0][0],ranges[-1][1],kinds

def overlap(first,last,target,get_bounds):
    lo,hi=first,last
    while lo<hi:
        mid=(lo+hi)//2
        if get_bounds(mid)[1]<target:lo=mid+1
        else:hi=mid
    begin=lo;lo,hi=begin,last
    while lo<hi:
        mid=(lo+hi)//2
        if get_bounds(mid)[0]<=target:lo=mid+1
        else:hi=mid
    return range(begin,lo)

def read_selection(path,requested,expected_epoch):
    import osmium
    if not requested or any(c[0]!='r' for c in requested):raise ValueError('Relation-only request required')
    start=time.monotonic();index_dir=ROOT/'work/osm-acq2c-bulk/pbf-framing-index-20261023';raw=(index_dir/'report.json').read_bytes();manifest=json.loads((index_dir/'manifest-sha256.json').read_bytes())
    if manifest['files']!=[dict(name='report.json',bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())]:raise ValueError('Index manifest differs')
    index=json.loads(raw);before=path.stat()
    if (before.st_size,before.st_mtime_ns)!=(163893678040,1792742452324164000):raise ValueError('Original stat changed')
    validate_index(index,before.st_size);blocks=index['blocks'];types={};bounds={};inspected={};read_bytes=0
    if not isinstance(OUTPUT_DIRECTORY,pathlib.Path):raise ValueError('Trusted caller must configure the output directory')
    state_path=OUTPUT_DIRECTORY/'range-progress.json'
    def progress(**extra):state_path.write_bytes(canonical(dict(source_qualified=False,publisher_sort_order_used_as_unverified_assumption=True,elapsed_seconds=time.monotonic()-start,source_bytes_read=read_bytes,inspected_blocks=len(inspected),**extra)))
    with path.open('rb') as source:
        def read(i):
            nonlocal read_bytes
            if time.monotonic()-start>600:raise TimeoutError('Range lookup exceeded600seconds')
            r=blocks[i];source.seek(r['offset']);data=source.read(r['end']-r['offset']);read_bytes+=len(data)
            if len(data)!=r['end']-r['offset'] or struct.unpack('>I',data[:4])[0]!=r['header_bytes']:raise ValueError('Source framing differs')
            kind,size=blob_header(data[4:4+r['header_bytes']])
            if kind!=r['kind'] or size!=r['blob_bytes']:raise ValueError('Source blob header differs')
            inspected[i]=hashlib.sha256(data).hexdigest();return data,data[4+r['header_bytes']:]
        header,blob=read(0)
        if hashlib.sha256(header).hexdigest()!='2f7052cfd92e08ca28fed1467fe24e6bd7428e6f4a83c08d855509cd9bda51b7':raise ValueError('Original dataset header differs')
        declaration=declared_sorted_history(blob)
        def get_types(i):
            if i not in types:types[i]=entity_types(read(i)[1])
            return types[i]
        first=first_relation(len(blocks),get_types)
        def get_bounds(i):
            if i not in bounds:
                a,b,kind=relation_bounds(read(i)[1])
                if i>first and kind!={'r'}:raise ValueError('Declared type order contradicted')
                bounds[i]=(a,b)
            return bounds[i]
        chosen=set();ids=sorted(int(code[1:]) for code in requested)
        for n,target in enumerate(ids,1):
            for i in overlap(first,len(blocks),target,get_bounds):
                a,b=get_bounds(i)
                if not a<=target<=b:raise ValueError('Nonmonotonic range lookup')
                chosen.add(i)
            if n%100==0:progress(phase='LOCATING_ORIGINAL_ID_RANGES',requested_ids_inspected=n,selected_blocks=len(chosen))
        progress(phase='PARSING_SELECTED_ORIGINAL_BLOCKS',selected_blocks=len(chosen),requested_ids_inspected=len(ids))
        native=osmium.filter.IdFilter(set(ids));pool=osmium.io.ThreadPool(2)
        for n,i in enumerate(sorted(chosen),1):
            block,payload=read(i);processor=osmium.FileProcessor(osmium.io.FileBuffer(header+block,'pbf'),entities=osmium.osm.RELATION,thread_pool=pool).with_filter(native)
            if not processor.header.has_multiple_object_versions or processor.header.get('osmosis_replication_timestamp')!=expected_epoch:raise ValueError('Original projected epoch differs')
            for obj in processor:
                if obj.type_str()+str(obj.id) in requested:yield object_record(obj)
            if n%50==0:progress(phase='PARSING_SELECTED_ORIGINAL_BLOCKS',selected_blocks=len(chosen),parsed_blocks=n)
    if (path.stat().st_size,path.stat().st_mtime_ns)!=(before.st_size,before.st_mtime_ns):raise ValueError('Original changed')
    receipt=dict(source_qualified=False,global_sorting_verified=False,publisher_sort_order_used_as_unverified_assumption=True,method='PER_ID_ORIGINAL_BLOCK_RANGES_UNDER_PUBLISHER_SORT_DECLARATION',framing_index_sha256=hashlib.sha256(raw).hexdigest(),first_relation_block=first,selected_blocks=sorted(chosen),source_blocks_inspected={str(k):v for k,v in sorted(inspected.items())},source_bytes_read=read_bytes,elapsed_seconds=time.monotonic()-start,original_rehashed=False,original_downloaded=False,declaration=declaration)
    with (state_path.parent/'index-window-metadata.json').open('xb') as f:f.write(canonical(receipt))
    progress(phase='INDEXED_BLOCK_PARSE_FINISHED_NOT_QUALIFIED',selected_blocks=len(chosen),parsed_blocks=len(chosen))
