"""Authenticate the existing45diffs once and index all relation observations."""
import pathlib,sys,json,hashlib,datetime
ROOT=pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'work/doc-supplement/scripts/audit'))
from osm_acq2c_replication_chain import audit,extract_versions
from osm_acq2c_selected_epoch_core import tail_record
from osm_acq2c_native_extract import canonical
source=ROOT/'outputs/ROADMAP-RESUME-20261022/replication-research';bulk=ROOT/'work/osm-acq2c-bulk'
out=bulk/'relation-tail-index-20261024';out.mkdir(exist_ok=False)
doc=json.loads((source/'states.json').read_bytes());states=doc['states'];receipts=[json.loads((source/(str(s['sequence'])+'-receipt.json')).read_bytes()) for s in states[1:]];by_seq={r['sequence']:r for r in receipts}
class AllRelations:
    def __contains__(self,code):return code.startswith('r')
count=0;identities=set();bindings=[]
with (out/'relation-tail.jsonl').open('xb') as target:
    def read_diff(seq):
        global count
        raw=(bulk/'replication-originals'/(str(seq)+'.osc.gz')).read_bytes();receipt=by_seq[seq]
        if len(raw)!=receipt['bytes'] or hashlib.sha256(raw).hexdigest()!=receipt['sha256']:raise ValueError('Replication original changed')
        rows=extract_versions(raw,AllRelations())
        for row in rows:
            normalized=tail_record(row)
            if not normalized['code'].startswith('r'):raise ValueError('Nonrelation in relation scope')
            target.write(canonical(dict(row,replication_sequence=seq)));count+=1;identities.add(normalized['code'])
        bindings.append(dict(sequence=seq,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),relation_observations=len(rows)))
        print(json.dumps(dict(sequence=seq,relation_observations=len(rows))),flush=True)
        return raw
    chain=audit(states,doc['base_epoch'],doc['target_epoch'],lambda seq:(source/(str(seq)+'.state.txt')).read_bytes(),read_diff,receipts)
report=dict(scope='All relation observations, including retained post-target changes, in the45authenticated originals',base_epoch=doc['base_epoch'],target_epoch=doc['target_epoch'],chain=chain,relation_observations=count,distinct_relations=len(identities),bindings=bindings,captured_receipt_selected_count_is_historical_scope=True,source_qualified=False,dependency_closure_certified=False,recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
(out/'report.json').write_bytes(canonical(report));files=[dict(name=p.name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(out.iterdir())];(out/'manifest-sha256.json').write_bytes(canonical(dict(files=files,source_qualified=False)));print(json.dumps(dict(status='RELATION_TAIL_OBSERVATIONS_INDEXED_NOT_SOURCE_ADMISSION',relation_observations=count,distinct_relations=len(identities))))
