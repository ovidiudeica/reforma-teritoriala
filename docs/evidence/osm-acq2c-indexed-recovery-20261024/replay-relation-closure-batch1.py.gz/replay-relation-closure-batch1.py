import pathlib,sys,json,hashlib,collections,datetime
ROOT=pathlib.Path(__file__).resolve().parent.parent;B=ROOT/'work/osm-acq2c-bulk'
sys.path[:0]=[str(ROOT/'work'),str(ROOT/'work/doc-supplement/scripts/audit')]
from frontier_stream_replay import replay_groups
from osm_acq2c_native_extract import canonical,request_ids
from osm_acq2c_selected_epoch_core import tail_record,moment

def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8388608),b''):h.update(b)
 return h.hexdigest()
def verify(folder):
 m=json.loads((folder/'manifest-sha256.json').read_bytes());seen=set()
 for r in m['files']:
  n=r['name']
  if pathlib.Path(n).name!=n or n in seen:raise ValueError('Unsafe manifest')
  seen.add(n);p=folder/n
  if p.stat().st_size!=r['bytes'] or digest(p)!=r['sha256']:raise ValueError('Digest mismatch')
 return digest(folder/'manifest-sha256.json')
base=B/'relation-closure-batch1-base-20261024';cache=B/'relation-tail-index-20261024';bindings={'base':verify(base),'tail':verify(cache)}
plan=B/'relation-closure-batch1-ids.txt'
if digest(plan)!='8fbdc1e1df383dec3321f305e7f4bfbfd007a3195497d3fd3e7197d753c0264e':raise ValueError('Plan changed')
ids=request_ids(plan.read_text().splitlines());meta=json.loads((cache/'report.json').read_bytes())
if moment(meta['base_epoch'])!=moment('2026-10-19T00:00:04Z') or moment(meta['target_epoch'])!=moment('2026-10-20T20:23:47Z'):raise ValueError('Wrong epochs')
tail=[]
for line in (cache/'relation-tail.jsonl').open('rb'):
 row=json.loads(line)
 if tail_record(row)['code'] in ids:tail.append(row)
out=B/'relation-closure-batch1-epoch-20261024';out.mkdir(exist_ok=False)
with (out/'selected-history.jsonl').open('xb') as f:
 result=replay_groups((json.loads(line) for line in (base/'selected-base-history.jsonl').open('rb')),tail,ids,meta['base_epoch'],meta['target_epoch'],lambda r:f.write(canonical(r)))
(out/'selected-target.json').write_bytes(canonical(result.pop('selected')))
result.update(requested=len(ids),tail_observations=len(tail),input_manifests=bindings,base_epoch=meta['base_epoch'],target_epoch=meta['target_epoch'],global_sorting_verified=False,publisher_sort_order_used_as_unverified_assumption=True,publisher_receipt_crosscheck='REQUIRES_INDEPENDENT_HUMAN_OR_SIGNED_VALIDATION',producer_sha256=digest(pathlib.Path(__file__)))
(out/'report.json').write_bytes(canonical(result));files=[dict(name=p.name,bytes=p.stat().st_size,sha256=digest(p)) for p in sorted(out.iterdir())];(out/'manifest-sha256.json').write_bytes(canonical(dict(files=files,source_qualified=False)));print(json.dumps(result))
