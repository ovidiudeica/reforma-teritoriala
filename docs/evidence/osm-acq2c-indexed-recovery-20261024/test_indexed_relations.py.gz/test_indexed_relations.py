import unittest,pathlib,sys,copy
root=pathlib.Path(__file__).resolve().parent.parent;sys.path[:0]=[str(root/'work/gis-runtime'),str(root/'work/doc-supplement/scripts/audit')]
from pbf_indexed_relations import validate_index,first_relation
class Tests(unittest.TestCase):
    def sample(self):return dict(complete=True,source_bytes=20,source_qualified=False,blocks=[dict(offset=0,header_bytes=1,blob_bytes=1,kind='OSMHeader',end=6),dict(offset=6,header_bytes=1,blob_bytes=9,kind='OSMData',end=20)])
    def test_complete_chain(self):validate_index(self.sample(),20)
    def test_missing_prefix(self):
        r=self.sample();r['blocks'][0]['offset']=1;self.assertRaises(ValueError,validate_index,r,20)
    def test_missing_suffix(self):
        r=self.sample();r['blocks'].pop();self.assertRaises(ValueError,validate_index,r,20)
    def test_partial_index(self):
        r=self.sample();r['complete']=False;self.assertRaises(ValueError,validate_index,r,20)
    def test_wrong_size(self):self.assertRaises(ValueError,validate_index,self.sample(),21)
    def test_no_false_qualification(self):
        r=self.sample();r['source_qualified']=True;self.assertRaises(ValueError,validate_index,r,20)
    def test_boolean_offset(self):
        r=self.sample();r['blocks'][0]['offset']=False;self.assertRaises(ValueError,validate_index,r,20)
    def test_binary_type_boundary(self):
        types={1:{'n'},2:{'w'},3:{'w','r'},4:{'r'},5:{'r'}}
        self.assertEqual(first_relation(6,types.__getitem__),3)
    def test_no_relations(self):self.assertRaises(ValueError,first_relation,5,lambda i:{'w'})
    def test_single_relation_block(self):self.assertEqual(first_relation(2,lambda i:{'r'}),1)
    def test_shared_bounded_native_pool(self):
        import osmium
        pool=osmium.io.ThreadPool(2);self.assertIsNotNone(pool)
if __name__=='__main__':unittest.main()
