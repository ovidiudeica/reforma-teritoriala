"""Conditional read of the relation tail, using a publisher-declared sort order.

The original bytes and every selected version are preserved. This does not
independently prove global sorting, historical continuity or source admission.
"""
import pathlib,sys,json,hashlib,struct,time
ROOT=pathlib.Path(__file__).resolve().parent.parent
sys.path[:0]=[str(ROOT/'work/gis-runtime'),str(ROOT/'work/doc-supplement/scripts/audit')]
from osm_acq2c_pbf_blocks import blob_header
from pbf_index_payload import entity_types,declared_sorted_history
from osm_acq2c_native_extract import object_record,canonical

def validate_index(report,length):
    if report.get('complete') is not True or report.get('source_bytes')!=length or report.get('source_qualified') is not False:raise ValueError('Framing index incomplete or incompatible')
    offset=0
    for i,row in enumerate(report['blocks']):
        if any(type(row.get(k)) is not int for k in ('offset','header_bytes','blob_bytes','end')):raise ValueError('Invalid framing coordinates')
        if row['offset']!=offset or not 0<row['header_bytes']<=65536 or not 0<row['blob_bytes']<=33554432:raise ValueError('Noncontiguous framing')
        if row['kind']!=('OSMHeader' if i==0 else 'OSMData'):raise ValueError('Framing type differs')
        if row['end']!=offset+4+row['header_bytes']+row['blob_bytes'] or row['end']>length:raise ValueError('Framing end differs')
        offset=row['end']
    if offset!=length:raise ValueError('Index omits source suffix')

def first_relation(count,get_types):
    lo,hi=1,count
    while lo<hi:
        mid=(lo+hi)//2
        if 'r' in get_types(mid):hi=mid
        else:lo=mid+1
    if lo==count or 'r' not in get_types(lo):raise ValueError('No relation tail under declared ordering')
    if lo>1 and 'r' in get_types(lo-1):raise ValueError('Boundary search differs')
    return lo

def read_selection(path,requested,expected_epoch):
    import osmium
    if not requested or any(c[0]!='r' for c in requested):raise ValueError('Relation-only request required')
    started=time.monotonic()
    directory=ROOT/'work/osm-acq2c-bulk/pbf-framing-index-20261023';raw=(directory/'report.json').read_bytes()
    manifest=json.loads((directory/'manifest-sha256.json').read_bytes())
    if manifest['files']!=[dict(name='report.json',bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())]:raise ValueError('Index manifest differs')
    report=json.loads(raw);before=path.stat()
    if (before.st_size,before.st_mtime_ns)!=(163893678040,1792742452324164000):raise ValueError('Original stat changed')
    validate_index(report,before.st_size);blocks=report['blocks'];types={};inspected={};total_read=0
    with path.open('rb') as source:
        def read(index):
            nonlocal total_read
            row=blocks[index];source.seek(row['offset']);data=source.read(row['end']-row['offset']);total_read+=len(data)
            if len(data)!=row['end']-row['offset'] or struct.unpack('>I',data[:4])[0]!=row['header_bytes']:raise ValueError('Source block prefix differs')
            kind,size=blob_header(data[4:4+row['header_bytes']])
            if kind!=row['kind'] or size!=row['blob_bytes']:raise ValueError('Source block framing differs')
            inspected[index]=hashlib.sha256(data).hexdigest()
            return data,data[4+row['header_bytes']:]
        header,header_blob=read(0)
        if hashlib.sha256(header).hexdigest()!='2f7052cfd92e08ca28fed1467fe24e6bd7428e6f4a83c08d855509cd9bda51b7':raise ValueError('Original header differs')
        declaration=declared_sorted_history(header_blob)
        def get_types(index):
            if index not in types:types[index]=entity_types(read(index)[1])
            return types[index]
        first=first_relation(len(blocks),get_types)
        if 'r' not in get_types(len(blocks)-1):raise ValueError('Declared relation tail not observed at EOF')
        native=osmium.filter.IdFilter({int(c[1:]) for c in requested});pool=osmium.io.ThreadPool(2)
        for index in range(first,len(blocks)):
            if time.monotonic()-started>600:raise TimeoutError('Bounded indexed relation read exceeded600seconds')
            block,payload=read(index);kind=entity_types(payload)
            if 'r' not in kind or index>first and kind!={'r'}:raise ValueError('Declared type order contradicted within inspected tail')
            processor=osmium.FileProcessor(osmium.io.FileBuffer(header+block,'pbf'),entities=osmium.osm.RELATION,thread_pool=pool).with_filter(native)
            if not processor.header.has_multiple_object_versions or processor.header.get('osmosis_replication_timestamp')!=expected_epoch:raise ValueError('Projected block epoch/history differs')
            for obj in processor:
                if obj.type_str()+str(obj.id) in requested:yield object_record(obj)
    if (path.stat().st_size,path.stat().st_mtime_ns)!=(before.st_size,before.st_mtime_ns):raise ValueError('Original changed during indexed selection')
    receipt=dict(source_qualified=False,global_sorting_verified=False,publisher_sort_order_used_as_unverified_assumption=True,method='ORIGINAL_HEADER_AND_CONTIGUOUS_ORIGINAL_RELATION_TAIL_BLOCKS',first_relation_block=first,relation_blocks=len(blocks)-first,framing_index_sha256=hashlib.sha256(raw).hexdigest(),source_bytes_read=total_read,source_blocks_inspected={str(k):v for k,v in sorted(inspected.items())},original_rehashed=False,original_downloaded=False,original_stat_unchanged=True,declaration=declaration)
    # Caller archives selected histories separately. This receipt is not global
    # sorting certification or an upgrade of their provenance status.
    target=ROOT/'work/osm-acq2c-bulk/relation-indexed-base-20261023/index-window-metadata.json'
    with target.open('xb') as stream:stream.write(canonical(receipt))
