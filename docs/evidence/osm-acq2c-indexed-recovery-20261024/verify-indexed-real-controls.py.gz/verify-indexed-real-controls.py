import pathlib,json,hashlib,sys
ROOT=pathlib.Path(__file__).resolve().parent.parent;B=ROOT/'work/osm-acq2c-bulk'
sys.path.insert(0,str(ROOT/'work/doc-supplement/scripts/audit'))
from osm_acq2c_native_extract import canonical
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
proof=json.loads((ROOT/'work/doc-supplement/docs/evidence/osm-acq2c-typed-reader-20261023/round2-recovery.json').read_bytes());old=B/'recursive-round2-base-20261023';new=B/'relation-closure-batch1-base-20261024'
if digest(old/'report.json')!=proof['base_report_sha256']:raise ValueError('Original full-scan receipt changed')
plan=json.loads((B/'relation-closure-batch1-plan.json').read_bytes());controls=set(plan['controls'])
if len(controls)!=400 or controls&set(plan['new_relations']):raise ValueError('Control cohort changed')
def rows(directory):
    file=directory/'selected-base-history.jsonl';manifest=json.loads((directory/'manifest-sha256.json').read_bytes());entry=next(r for r in manifest['files'] if r['name']==file.name)
    if file.stat().st_size!=entry['bytes'] or digest(file)!=entry['sha256']:raise ValueError('History input changed')
    values={}
    with file.open('rb') as source:
        for line in source:
            row=json.loads(line)
            if row['code'] not in controls:continue
            key=row['code'],row['version']
            if key in values:raise ValueError('Duplicate control version')
            values[key]=canonical(row)
    return values,entry
a,old_entry=rows(old);b,new_entry=rows(new)
if a!=b or {k[0] for k in a}!=controls:raise ValueError('Indexed control histories differ from independent full reader')
ordered=lambda values:b''.join(values[k] for k in sorted(values,key=lambda k:(int(k[0][1:]),k[1])))
result=dict(status='400_FROZEN_RELATION_HISTORY_STREAMS_BYTE_IDENTICAL',controls=400,versions=len(a),canonical_control_stream_sha256=hashlib.sha256(ordered(a)).hexdigest(),old_history=old_entry,new_history=new_entry,rows=[dict(code=code,versions=sum(k[0]==code for k in a),history_sha256=hashlib.sha256(b''.join(a[k] for k in sorted(a,key=lambda k:k[1]) if k[0]==code)).hexdigest()) for code in sorted(controls)],source_qualified=False,global_sorting_verified=False,limits='Agreement is for these400frozen histories only, not global sorting or Overpass/generated-area equivalence.')
out=ROOT/'outputs/ROADMAP-20261024/indexed-real-controls-400';out.mkdir(exist_ok=False);raw=canonical(result);(out/'report.json').write_bytes(raw);(out/'manifest-sha256.json').write_bytes(canonical(dict(files=[dict(name='report.json',bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())],source_qualified=False)))
print(json.dumps({k:v for k,v in result.items() if k not in ('rows','old_history','new_history')}))
