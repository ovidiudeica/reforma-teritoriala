import unittest,zlib,pathlib,sys,tempfile
root=pathlib.Path(__file__).resolve().parent.parent
sys.path[:0]=[str(root/'work/gis-runtime'),str(root/'work/doc-supplement/scripts/audit')]
from pbf_index_payload import unpack_blob,entity_types,declared_sorted_history
def varint(n):
    out=[]
    while n>=128:out.append((n&127)|128);n>>=7
    return bytes(out+[n])
def data(n,v):return varint((n<<3)|2)+varint(len(v))+v
def blob(raw):return data(1,raw)
class Tests(unittest.TestCase):
    def test_uncompressed(self):self.assertEqual(unpack_blob(blob(b'test')),b'test')
    def test_compressed(self):self.assertEqual(unpack_blob(b'\x10\x04'+data(3,zlib.compress(b'test'))),b'test')
    def test_duplicate_payload(self):self.assertRaises(ValueError,unpack_blob,blob(b'a')+blob(b'b'))
    def test_wrong_raw_size(self):self.assertRaises(ValueError,unpack_blob,b'\x10\x03'+data(3,zlib.compress(b'test')))
    def test_truncated_compressed(self):self.assertRaises(ValueError,unpack_blob,b'\x10\x04'+data(3,zlib.compress(b'test')[:-1]))
    def test_compressed_trailing_data(self):self.assertRaises(ValueError,unpack_blob,b'\x10\x04'+data(3,zlib.compress(b'test')+b'x'))
    def test_oversized_expansion(self):self.assertRaises(ValueError,unpack_blob,b'\x10\x01'+data(3,zlib.compress(b'x'*100)))
    def test_single_group(self):self.assertEqual(entity_types(blob(data(1,b'')+data(2,data(4,b'')))),{'r'})
    def test_separate_types_in_separate_groups(self):self.assertEqual(entity_types(blob(data(1,b'')+data(2,data(3,b''))+data(2,data(4,b'')))),{'w','r'})
    def test_mixed_group_rejected(self):self.assertRaises(ValueError,entity_types,blob(data(1,b'')+data(2,data(3,b'')+data(4,b''))))
    def test_missing_table(self):self.assertRaises(ValueError,entity_types,blob(data(2,data(4,b''))))
    def test_missing_sorted_flag(self):self.assertRaises(ValueError,declared_sorted_history,blob(data(4,b'HistoricalInformation')))
    def test_declaration_is_not_global_validation(self):
        result=declared_sorted_history(blob(data(4,b'HistoricalInformation')+data(5,b'Sort.Type_then_ID')))
        self.assertFalse(result['source_qualified']);self.assertFalse(result['global_sorting_verified'])
    def test_real_native_filebuffer_and_type_detection(self):
        import osmium,struct
        with tempfile.TemporaryDirectory() as temp:
            p=pathlib.Path(temp)/'fixture.osh.pbf';h=osmium.io.Header();h.has_multiple_object_versions=True
            with osmium.SimpleWriter(str(p),header=h) as writer:writer.add_relation(osmium.osm.mutable.Relation(id=4,version=1,timestamp='2026-10-18T00:00:00Z',members=[]))
            raw=p.read_bytes();pos=0;kinds=set()
            from osm_acq2c_pbf_blocks import blob_header
            while pos<len(raw):
                n=struct.unpack('>I',raw[pos:pos+4])[0];kind,size=blob_header(raw[pos+4:pos+4+n]);payload=raw[pos+4+n:pos+4+n+size]
                if kind=='OSMData':kinds.update(entity_types(payload))
                pos+=4+n+size
            self.assertEqual(kinds,{'r'})
            rows=[(o.type_str(),o.id,o.version) for o in osmium.FileProcessor(osmium.io.FileBuffer(raw,'pbf'))]
            self.assertEqual(rows,[('r',4,1)])
if __name__=='__main__':unittest.main()
