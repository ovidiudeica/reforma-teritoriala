"""One justified independent native all-object order validation, not a hash rerun."""
import pathlib,subprocess,json,hashlib,datetime,os,time,traceback
R=pathlib.Path(__file__).resolve().parent.parent;D=R/'work/osmium-tool-qualification-20261024';B=R/'work/osm-acq2c-bulk';out=B/'independent-native-order-20261024'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def emit(n,v):
 (out/n).write_bytes((json.dumps(v,sort_keys=True,indent=2)+'\n').encode())
def run():
 out.mkdir(exist_ok=False)
 with (out/'exclusive-lock.json').open('x') as f:json.dump(dict(pid=os.getpid()),f)
 source=B/'history-261019.osm.pbf';before=source.stat();proof=R/'outputs/ROADMAP-20261023/checkpoint-20261023T101735Z-99edf59/base-independent-integrity.json'
 if digest(proof)!='4c8a0e8a974402dcebda42627b9c3aa5d956aba2219657e20cfa15b47f955943' or (before.st_size,before.st_mtime_ns)!=(163893678040,1792742452324164000):raise ValueError('Historical source identity changed')
 exe=D/'prefix/Library/bin/osmium.exe'
 if digest(exe)!='455925087048db47c32ef1c9f20533f343dfc60f2aa7db8a0bfeca4851eb42e3':raise ValueError('Qualified executable changed')
 for n,r in json.loads((D/'minimal-dll-manifest.json').read_bytes())['files'].items():
  if pathlib.Path(n).name!=n or digest(exe.parent/n)!=r['sha256']:raise ValueError('Qualified dependency changed')
 fixtures=json.loads((D/'ordering-fixtures.json').read_bytes())
 if fixtures['status']!='PASS' or [x['result'] for x in fixtures['tests']]!=['yes','no']:raise ValueError('Independent positive/negative checker tests missing')
 args=[str(exe),'fileinfo','--extended','--json','--no-crc','--no-progress',str(source)]
 start=time.monotonic()
 with (out/'stdout.json').open('xb') as stdout,(out/'stderr.txt').open('xb') as stderr:
  p=subprocess.Popen(args,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
  emit('worker.json',dict(pid=os.getpid(),native_pid=p.pid,phase='INDEPENDENT_NATIVE_FULL_ORDER_SCAN',started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),global_sorting_verified=False,source_qualified=False,original_rehashed=False,arguments=args))
  try:code=p.wait(timeout=7200)
  except subprocess.TimeoutExpired:p.terminate();p.wait(timeout=30);raise TimeoutError('Bounded native independent scan exceeded two hours')
 if code:raise RuntimeError('Native order check failed: '+str(code))
 after=source.stat()
 if (before.st_size,before.st_mtime_ns)!=(after.st_size,after.st_mtime_ns):raise ValueError('Original changed during scan')
 result=json.loads((out/'stdout.json').read_bytes());ordered=result['data']['objects_ordered']
 if ordered is not True:raise ValueError('Native checker reports unordered input')
 emit('report.json',dict(status='INDEPENDENT_NATIVE_ALL_OBJECT_ORDER_CHECK_PASS',global_sorting_verified=True,source_qualified=False,provenance_human_or_signed_validation_pending=True,original_rehashed=False,prior_integrity_proof_sha256=digest(proof),original_sha256=json.loads(proof.read_bytes())['sha256'],source_stat_unchanged=True,elapsed_seconds=time.monotonic()-start,executable_sha256=digest(exe),positive_negative_fixture_sha256=digest(D/'ordering-fixtures.json'),native_stdout_sha256=digest(out/'stdout.json'),native_exit_code=code))
 emit('manifest-sha256.json',dict(files=[dict(name=p.name,bytes=p.stat().st_size,sha256=digest(p)) for p in sorted(out.iterdir()) if p.name not in ('worker.json','exclusive-lock.json')],source_qualified=False))
 emit('worker.json',dict(pid=os.getpid(),phase='INDEPENDENT_NATIVE_FULL_ORDER_SCAN_FINISHED',global_sorting_verified=True,source_qualified=False,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat()))
 print(json.dumps(json.loads((out/'report.json').read_bytes())))
if __name__=='__main__':
 try:run()
 except Exception as e:
  if out.exists():emit('failure.json',dict(error=str(e),traceback=traceback.format_exc(),source_qualified=False));emit('worker.json',dict(pid=os.getpid(),phase='STOPPED_WITHOUT_QUALIFICATION',error=str(e),global_sorting_verified=False,source_qualified=False))
  raise
