import pathlib,sys,tempfile,json,subprocess
R=pathlib.Path(__file__).resolve().parent.parent;sys.path.insert(0,str(R/'work/gis-runtime'));import osmium
d=R/'work/osmium-tool-qualification-20261024';exe=d/'prefix/Library/bin/osmium.exe';reports=[]
with tempfile.TemporaryDirectory() as tmp:
 for label,ids in [('ordered',[17,17,18]),('unsorted',[18,17,17])]:
  p=pathlib.Path(tmp)/(label+'.osh.pbf');h=osmium.io.Header();h.has_multiple_object_versions=True
  with osmium.SimpleWriter(str(p),header=h) as w:
   versions={}
   for n in ids:
    versions[n]=versions.get(n,0)+1;w.add_way(osmium.osm.mutable.Way(id=n,version=versions[n],nodes=[1,2,1],timestamp='2026-10-01T00:00:00Z'))
  result=subprocess.run([str(exe),'fileinfo','-e','--no-crc','--get=data.objects_ordered',str(p)],capture_output=True,timeout=30,check=True)
  observed=result.stdout.decode().strip();expected='yes' if label=='ordered' else 'no'
  if observed!=expected:raise ValueError('Native ordering fixture mismatch: '+repr(observed))
  reports.append(dict(label=label,ids=ids,result=observed,exit_code=result.returncode))
(d/'ordering-fixtures.json').write_bytes((json.dumps(dict(status='PASS',tests=reports,original_read=False),indent=2)+'\n').encode());print(json.dumps(reports))
