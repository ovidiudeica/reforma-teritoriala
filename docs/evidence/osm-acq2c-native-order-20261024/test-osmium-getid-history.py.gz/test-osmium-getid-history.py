import pathlib,sys,tempfile,json,subprocess
R=pathlib.Path(__file__).resolve().parent.parent;sys.path.insert(0,str(R/'work/gis-runtime'));import osmium
D=R/'work/osmium-tool-qualification-20261024';exe=D/'prefix/Library/bin/osmium.exe';reports=[]
with tempfile.TemporaryDirectory() as tmp:
 d=pathlib.Path(tmp);p=d/'fixture.osh.pbf';header=osmium.io.Header();header.has_multiple_object_versions=True
 with osmium.SimpleWriter(str(p),header=header) as w:
  for n,v in [(1,1),(1,2),(2,1),(3,1)]:w.add_node(osmium.osm.mutable.Node(id=n,version=v,location=(28.0,47.0),timestamp='2026-10-01T00:00:00Z'))
  for v,refs in [(1,[1,2]),(2,[1,3])]:w.add_way(osmium.osm.mutable.Way(id=17,version=v,nodes=refs,timestamp='2026-10-01T00:00:00Z'))
 for label,requested in [('recursive','w17'),('missing','w999')]:
  out=d/(label+'.osh.pbf');r=subprocess.run([str(exe),'getid','-H','-r','--no-progress',str(p),requested,'-o',str(out)],capture_output=True,timeout=30,check=True)
  rows=[(o.type_str()+str(o.id),o.version) for o in osmium.FileProcessor(str(out))]
  if label=='recursive' and rows!=[('n1',1),('n1',2),('n2',1),('n3',1),('w17',1),('w17',2)]:raise ValueError('Lost recursive history')
  if label=='missing' and rows:raise ValueError('Unexpected missing output')
  reports.append(dict(label=label,requested=requested,exit_code=r.returncode,rows=rows))
report=dict(status='PASS',cases=reports,missing_ids_must_be_detected_independently=True,warning='With-history exit0 is not completeness proof',original_read=False,manual_url='https://docs.osmcode.org/osmium/latest/osmium-getid.html')
(D/'getid-history-fixtures.json').write_bytes((json.dumps(report,indent=2)+'\n').encode());print(json.dumps(report))
