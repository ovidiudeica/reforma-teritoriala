import pathlib,json,urllib.request,urllib.error,hashlib,time,datetime,re
ROOT=pathlib.Path.cwd(); OUT=ROOT/'outputs'/('OSM-FIX3-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ'));OUT.mkdir(exist_ok=False)
BASE='https://api.openstreetmap.org/api/0.6/'
retired=[18966859,18966939,18967312,18967475,18967641,18967824,18967907,18967934,18968041,18968051,18968093,18968144]
rows=[]
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*args,**kwargs):return None
opener=urllib.request.build_opener(NoRedirect)
allowed={'type','id','version','timestamp','changeset','visible','tags','members','nodes','lat','lon'}
def get(path):
 assert re.fullmatch(r'(relation|way|node)/[1-9][0-9]*(/(history|full|ways|relations))?\.json',path)
 for attempt in range(1,3):
  started=datetime.datetime.now(datetime.timezone.utc).isoformat();status=None;body=b'';headers={};error=None
  try:
   with opener.open(urllib.request.Request(BASE+path,headers={'User-Agent':'ReformaTeritoriala-OSM-FIX3/1.0 (bounded read-only audit)'}),timeout=25) as response:status=response.status;body=response.read();headers=dict(response.headers)
  except urllib.error.HTTPError as e:status=e.code;body=e.read();headers=dict(e.headers)
  except (urllib.error.URLError,TimeoutError) as e:error=type(e).__name__+': '+str(e)
  digest=hashlib.sha256(body).hexdigest();name=hashlib.sha256((path+str(attempt)+started).encode()).hexdigest()+'.response';(OUT/name).write_bytes(body)
  elements=[]
  if status==200:
   try:
    v=json.loads(body);assert isinstance(v.get('elements'),list);elements=[{k:x[k] for k in x if k in allowed} for x in v['elements']]
   except (ValueError,AssertionError) as e:error='INVALID_OSM_JSON: '+str(e)
  row={'path':path,'url':BASE+path,'accessed_at':started,'http_status':status,'attempt':attempt,'date':headers.get('Date'),'content_type':headers.get('Content-Type'),'bytes':len(body),'raw_sha256':digest,'private_original':name,'error':error,'elements':elements};rows.append(row);(OUT/'receipts.json').write_bytes((json.dumps(rows,ensure_ascii=False,indent=2)+'\n').encode())
  if status not in [429,502,503,504] and error is None:break
  if attempt==2:break
  retry=headers.get('Retry-After','2')
  try:delay=float(retry)
  except ValueError:break
  if delay<0 or delay>10:break
  time.sleep(max(2,delay))
 time.sleep(.25)
 return row
for rid in retired+[21515245]:
 for op in ['', '/history']:get(f'relation/{rid}{op}.json')
for rid in [18967493,18968082,21515245]:get(f'relation/{rid}/full.json')
for nid in [12318728194,12318728593,11649857778,8265822008]:get(f'node/{nid}/ways.json')
parents=set()
for wid in [1376179876,1376180731]:
 row=get(f'way/{wid}/relations.json');parents.update(x['id'] for x in row['elements'] if x['type']=='relation')
if len(parents)>16:raise RuntimeError('Parent impact exceeds bounded scope; no automatic exclusion')
for rid in sorted(parents):
 if rid not in [18967493,18968082,21515245]:get(f'relation/{rid}/full.json')
 get(f'relation/{rid}/relations.json')
(OUT/'scope.json').write_bytes((json.dumps({'scope':'Per-ID live transition and isolated topology diagnostic only','snapshot_atomic_certified':False,'candidate_validated':False,'source_promoted':False,'public_osm_edited':False,'requests':len(rows),'parents':sorted(parents)},indent=2)+'\n').encode())
(ROOT/'outputs/osm-fix3-current-location.txt').write_bytes(str(OUT).encode());print(str(OUT),len(rows),'requests',flush=True)
