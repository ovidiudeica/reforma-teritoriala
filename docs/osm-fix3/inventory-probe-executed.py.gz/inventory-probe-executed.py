import pathlib,json,urllib.request,urllib.error,hashlib,datetime,time
root=pathlib.Path(pathlib.Path('outputs/osm-fix3-current-location.txt').read_text());rows=[];epoch='2026-10-20T20:23:47Z'
for code,levels,required in [('RO',[4,8,9],[]),('MD',[4,6,8,9],[1813306,1813297,58512,1813315,1813316,18968071,1691800,1691801,18822134])]:
 scope=f'relation["ISO3166-1"="{code}"]["boundary"="administrative"]->.countryRel;.countryRel map_to_area ->.country;(.countryRel;'+''.join(f'relation(area.country)["boundary"="administrative"]["admin_level"="{l}"];' for l in levels)+''.join(f'relation({i});' for i in required)+');'
 query=f'[out:json][timeout:20][date:"{epoch}"];'+scope+'out meta;'
 for endpoint in ['https://overpass-api.de/api/interpreter','https://overpass.kumi.systems/api/interpreter']:
  started=datetime.datetime.now(datetime.timezone.utc).isoformat();body=b'';status=None;err=None
  try:
   url=endpoint+'?data='+urllib.parse.quote(query)
   with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'ReformaTeritoriala-OSM-FIX3/1.0 read-only bounded inventory'}),timeout=25) as r:body=r.read();status=r.status
  except urllib.error.HTTPError as e:status=e.code;body=e.read()
  except (urllib.error.URLError,TimeoutError) as e:err=type(e).__name__+': '+str(e)
  name=f'overpass-{code}-{len(rows)}.response';(root/name).write_bytes(body);metadata=None;relations=[];remark=None
  if status==200:
   try:
    v=json.loads(body);metadata=v.get('osm3s');remark=v.get('remark');relations=[{k:x[k] for k in ['type','id','version','timestamp','changeset','tags','members'] if k in x} for x in v.get('elements',[]) if x.get('type')=='relation']
   except ValueError:err='INVALID_JSON'
  rows.append({'code':code,'endpoint':endpoint,'started_at':started,'query':query,'query_sha256':hashlib.sha256(query.encode()).hexdigest(),'http_status':status,'error':err,'bytes':len(body),'raw_sha256':hashlib.sha256(body).hexdigest(),'private_original':name,'metadata':metadata,'remark':remark,'relations':relations,'scope':'ATTIC_INVENTORY_ONLY_NOT_FULL_GRAPH_OR_GENERATED_AREA_CERTIFICATION'})
  (root/'overpass-inventory-probe.json').write_bytes((json.dumps(rows,ensure_ascii=False,indent=2)+'\n').encode())
  print(code,endpoint,status,len(relations),err,flush=True)
  if status==200 and not err and not remark and relations:break
  if status==429:break
  time.sleep(2)
print('bounded inventory diagnostic complete; no source qualification or promotion')
