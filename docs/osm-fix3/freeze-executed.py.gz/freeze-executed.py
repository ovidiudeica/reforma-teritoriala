import pathlib,json,gzip,hashlib,subprocess
r=pathlib.Path('docs/osm-fix3');r.mkdir(exist_ok=True);private=pathlib.Path(pathlib.Path('outputs/osm-fix3-current-location.txt').read_text());observations=json.loads((private/'receipts.json').read_text(encoding='utf-8'))
for row in observations:
 assert hashlib.sha256((private/row['private_original']).read_bytes()).hexdigest()==row['raw_sha256']
(r/'observations.json').write_bytes((json.dumps({'scope':'Official current per-ID diagnostic, not atomic snapshot','public_raw_upload':False,'rows':observations},ensure_ascii=False,indent=2)+'\n').encode())
(r/'transport-probe.json').write_bytes((private/'overpass-inventory-probe.json').read_bytes())
retired=[18966859,18966939,18967312,18967475,18967641,18967824,18967907,18967934,18968041,18968051,18968093,18968144]
mbytes=pathlib.Path('data/sources/osm-current.json').read_bytes();manifest=json.loads(mbytes);entry=manifest['countries']['MD'];compressed=pathlib.Path(entry['snapshot_path']).read_bytes();assert hashlib.sha256(compressed).hexdigest()==entry['compressed_sha256'];b=gzip.decompress(compressed);assert hashlib.sha256(b).hexdigest()==entry['semantic_sha256'];raw=json.loads(b);bykey={(x['type'],x['id']):x for x in raw['elements']};selected={}
def visit(key):
 if key in selected:return
 e=bykey[key];selected[key]=e
 if key[0]=='relation':
  for x in e.get('members',[]):visit((x['type'],x['ref']))
 elif key[0]=='way':
  for nid in e.get('nodes',[]):visit(('node',nid))
for rid in retired:visit(('relation',rid))
baseline={'snapshot_at':manifest['snapshot_at'],'manifest_path':'data/sources/osm-current.json','manifest_sha256':hashlib.sha256(mbytes).hexdigest(),'compressed_snapshot':{'path':entry['snapshot_path'],'sha256':entry['compressed_sha256'],'bytes':len(compressed)},'uncompressed_snapshot_sha256':entry['semantic_sha256'],'metadata_note':'Accepted normalized raw strips OSM versions. Relation versions at the accepted epoch are separately derived from complete official histories, never invented for way/node objects.','selected_retired_ids':retired,'elements':sorted(selected.values(),key=lambda x:(x['type'],x['id']))};(r/'baseline.json').write_bytes((json.dumps(baseline,ensure_ascii=False,indent=2)+'\n').encode())
# Verify all reused archived proof files against their frozen manifests, without downloading PBF originals.
archived=[];sha='027d66f6f08296fd9006938a010f8e18265aca36'
for directory in ['docs/evidence/osm-fix2/geofabrik-qualification-20261022','docs/evidence/osm-fix2/source-repair-review-20261021','docs/evidence/osm-fix2/layered-acquisition-20261021']:
 mb=subprocess.check_output(['git','show',sha+':'+directory+'/sha256-manifest.json']);mm=json.loads(mb);records=mm.get('files',mm.get('records',[]));checked=0
 for row in records:
  name=row.get('path',row.get('file'));name=name if name.startswith('docs/') else directory+'/'+name
  data=subprocess.check_output(['git','show',sha+':'+name]);assert hashlib.sha256(data).hexdigest()==row['sha256'],name;checked+=1
 archived.append({'git_commit':sha,'directory':directory,'manifest_sha256':hashlib.sha256(mb).hexdigest(),'verified_files':checked,'original_pbf_downloaded_or_rehashed':False})
(r/'archived-proof-bindings.json').write_bytes((json.dumps(archived,indent=2)+'\n').encode());print('PASS current37raw hashes; baseline MD gzip+semantic hashes; retired subset',len(selected),'objects; archived proof files',sum(x['verified_files'] for x in archived))
