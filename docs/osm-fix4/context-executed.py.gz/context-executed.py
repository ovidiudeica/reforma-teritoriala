import pathlib,json,urllib.request,hashlib,time,datetime
r=pathlib.Path(pathlib.Path('outputs/osm-fix4-current-location.txt').read_text());rows=[]
paths=[f'way/{i}/history.json' for i in [1376178758,1376180490,1492661493,1492661495,1494605625]]+['changeset/164736346.json?include_discussion=true']
for path in paths:
 url='https://api.openstreetmap.org/api/0.6/'+path;at=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'ReformaTeritoriala-OSM-FIX4/1.0 read-only historical intent context'}),timeout=25) as response:body=response.read();status=response.status
 name='context-'+hashlib.sha256(path.encode()).hexdigest()+'.private.json';(r/name).write_bytes(body);v=json.loads(body)
 if path.startswith('way/'):
  data=[{k:e[k] for k in ['type','id','version','visible','timestamp','changeset','nodes','tags'] if k in e} for e in v['elements']]
 else:
  c=v['changeset'];data={'id':c['id'],'tags':c.get('tags',{}),'comments_count':c.get('comments_count'),'discussion':[{k:x[k] for k in ['date','text'] if k in x} for x in c.get('discussion',[])]}
 rows.append({'url':url,'accessed_at':at,'http_status':status,'bytes':len(body),'raw_sha256':hashlib.sha256(body).hexdigest(),'private_original':name,'data':data});print(path,status,flush=True);time.sleep(.25)
(r/'supplemental-context.json').write_bytes((json.dumps(rows,ensure_ascii=False,indent=2)+'\n').encode());print('Completed6bounded context reads; no comments posted')
