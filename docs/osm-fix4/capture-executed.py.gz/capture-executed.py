import pathlib,json,urllib.request,urllib.error,hashlib,time,datetime,re,subprocess
ROOT=pathlib.Path.cwd(); OUT=ROOT/'outputs'/('OSM-FIX4-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ'));OUT.mkdir(exist_ok=False)
BASE='https://api.openstreetmap.org/api/0.6/'
rows=[]
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*args,**kwargs):return None
opener=urllib.request.build_opener(NoRedirect)
allowed={'type','id','version','timestamp','changeset','visible','tags','members','nodes','lat','lon'}
def get(path):
 assert re.fullmatch(r'(relation|way|node)/[1-9][0-9]*(/(history|full|ways|relations))?\.json',path)
 for attempt in range(1,3):
  started=datetime.datetime.now(datetime.timezone.utc).isoformat();status=None;body=b'';headers={};error=None
  try:
   with opener.open(urllib.request.Request(BASE+path,headers={'User-Agent':'ReformaTeritoriala-OSM-FIX3/1.0 (bounded read-only audit)'}),timeout=25) as response:status=response.status;body=response.read();headers=dict(response.headers)
  except urllib.error.HTTPError as e:status=e.code;body=e.read();headers=dict(e.headers)
  except (urllib.error.URLError,TimeoutError) as e:error=type(e).__name__+': '+str(e)
  digest=hashlib.sha256(body).hexdigest();name=hashlib.sha256((path+str(attempt)+started).encode()).hexdigest()+'.response';(OUT/name).write_bytes(body)
  elements=[]
  if status==200:
   try:
    v=json.loads(body);assert isinstance(v.get('elements'),list);elements=[{k:x[k] for k in x if k in allowed} for x in v['elements']]
   except (ValueError,AssertionError) as e:error='INVALID_OSM_JSON: '+str(e)
  row={'path':path,'url':BASE+path,'accessed_at':started,'http_status':status,'attempt':attempt,'date':headers.get('Date'),'content_type':headers.get('Content-Type'),'bytes':len(body),'raw_sha256':digest,'private_original':name,'error':error,'elements':elements};rows.append(row);(OUT/'receipts.json').write_bytes((json.dumps(rows,ensure_ascii=False,indent=2)+'\n').encode())
  if status not in [429,502,503,504] and error is None:break
  if attempt==2:break
  retry=headers.get('Retry-After','2')
  try:delay=float(retry)
  except ValueError:break
  if delay<0 or delay>10:break
  time.sleep(max(2,delay))
 time.sleep(.25)
 return row

for rid in [18967493,18968082]:get(f'relation/{rid}/full.json')
ways=set()
for nid in [12318728194,12318728593,11649857778,8265822008]:
 row=get(f'node/{nid}/ways.json');ways.update(e['id'] for e in row['elements'] if e['type']=='way')
if len(ways)>64:raise RuntimeError('Way frontier exceeds bounded scope; nothing excluded automatically')
parent_records={};parents_for_way={}
for wid in sorted(ways):
 row=get(f'way/{wid}/relations.json');parents_for_way[wid]=[e['id'] for e in row['elements'] if e['type']=='relation']
 for e in row['elements']:
  if e['type']=='relation':parent_records[e['id']]=e
if len(parent_records)>32:raise RuntimeError('Neighbor relation frontier exceeds bounded scope')
for rid,e in sorted(parent_records.items()):
 if rid not in [18967493,18968082] and (e.get('tags',{}).get('boundary')=='administrative' or e.get('tags',{}).get('type') in ['boundary','multipolygon']):get(f'relation/{rid}/full.json')
# Reverse parent chain only for actually edited way parents; no world/country census.
pending=sorted(set(parents_for_way.get(1376179876,[])+parents_for_way.get(1376180731,[])));seen=set()
while pending:
 rid=pending.pop(0)
 if rid in seen:continue
 if len(seen)>=32:raise RuntimeError('Ancestor frontier exceeds bounded scope')
 seen.add(rid);row=get(f'relation/{rid}/relations.json')
 for e in row['elements']:
  if e['type']=='relation' and e['id'] not in seen:
   get(f'relation/{e["id"]}/full.json');pending.append(e['id'])
# Preserve complete cached histories when immutable latest versions match current preflight.
SHA='027d66f6f08296fd9006938a010f8e18265aca36';DIR='docs/evidence/osm-fix2/source-repair-review-20261021/'
receipts=json.loads(subprocess.check_output(['git','show',SHA+':'+DIR+'source-history/receipts.json']))
index=json.loads(subprocess.check_output(['git','show',SHA+':'+DIR+'closure/index.json']))
caches=[]
for r in receipts:
 if '/history.json' in r['url']:caches.append((r['url'],DIR+'source-history/'+r['body_sha256']+'.response',r['body_sha256'],r['accessed_at']))
for e in index['entries']:
 if e['mode']=='history' and e['relation_id'] in [18967493,18968082]:
  r=e['attempts'][-1];caches.append((r['url'],DIR+'closure/'+r['body_sha256']+'.response',r['body_sha256'],r['accessed_at']))
current={(e['type'],e['id']):e for row in rows for e in row['elements']}
histories=[]
for url,path,digest,access in caches:
 data=subprocess.check_output(['git','show',SHA+':'+path]);assert hashlib.sha256(data).hexdigest()==digest
 parsed=json.loads(data)['elements'];target=parsed[-1];key=(target['type'],target['id']);latest=current.get(key)
 if not latest:raise RuntimeError('Missing current history endpoint witness '+str(key))
 if latest['version']!=target['version']:
  rr=get(f'{key[0]}/{key[1]}/history.json');histories.append({'url':rr['url'],'raw_sha256':rr['raw_sha256'],'reused':False,'history_captured_at':rr['accessed_at'],'elements':rr['elements']})
 else:histories.append({'url':url,'raw_sha256':digest,'reused':True,'git_commit':SHA,'git_path':path,'history_captured_at':access,'current_version_verified':latest['version'],'elements':[{k:e[k] for k in e if k in allowed} for e in parsed]})
changes=set()
for h in histories:
 elements=h['elements'];changes.add(elements[0]['changeset']);changes.add(elements[-1]['changeset'])
if len(changes)>24:raise RuntimeError('Changeset intent review exceeds bounded scope')
changesets=[]
for cid in sorted(changes):
 url=BASE+f'changeset/{cid}.json';started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 try:
  with opener.open(urllib.request.Request(url,headers={'User-Agent':'ReformaTeritoriala-OSM-FIX4/1.0 read-only mapper preflight'}),timeout=25) as response:data=response.read();status=response.status
  (OUT/f'changeset-{cid}.private.json').write_bytes(data);parsed=json.loads(data);elements=parsed.get('elements',[]);sanitized=[{k:e[k] for k in ['type','id','created_at','closed_at','open','tags','min_lat','min_lon','max_lat','max_lon','changes_count'] if k in e} for e in elements]
  changesets.append({'url':url,'accessed_at':started,'http_status':status,'raw_sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'elements':sanitized})
 except (urllib.error.URLError,TimeoutError,ValueError) as e:changesets.append({'url':url,'accessed_at':started,'error':str(e)})
 time.sleep(.25)
(OUT/'history-reuse.json').write_bytes((json.dumps(histories,ensure_ascii=False,indent=2)+'\n').encode())
(OUT/'changesets.json').write_bytes((json.dumps(changesets,ensure_ascii=False,indent=2)+'\n').encode())
(OUT/'scope.json').write_bytes((json.dumps({'scope':'Current local impact and mapper-intent evidence only; no upload, no source snapshot','ways_observed':sorted(ways),'neighbor_relations':sorted(parent_records),'changed_way_parent_ancestors':sorted(seen),'snapshot_atomic_certified':False,'public_osm_edited':False,'mapper_intent_confirmed':False},indent=2)+'\n').encode())
(ROOT/'outputs/osm-fix4-current-location.txt').write_bytes(str(OUT).encode());print(str(OUT),len(rows),'object requests',len(histories),'histories',len(changesets),'changeset reads',flush=True)
